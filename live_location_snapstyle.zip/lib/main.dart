
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:location/location.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController controller = TextEditingController();

  String generateCode() {
    final random = Random();
    return (100000 + random.nextInt(900000)).toString();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFFff00cc),
              Color(0xFF3333ff),
            ],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                "Live Location",
                style: TextStyle(
                    fontSize: 32,
                    color: Colors.white,
                    fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 30),
              ElevatedButton(
                onPressed: () {
                  String code = generateCode();
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => MapScreen(sessionId: code),
                    ),
                  );
                },
                child: const Text("Create Session"),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: 200,
                child: TextField(
                  controller: controller,
                  decoration: const InputDecoration(
                    filled: true,
                    fillColor: Colors.white,
                    hintText: "Enter Code",
                  ),
                ),
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          MapScreen(sessionId: controller.text),
                    ),
                  );
                },
                child: const Text("Join"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MapScreen extends StatefulWidget {
  final String sessionId;
  const MapScreen({super.key, required this.sessionId});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  final Location location = Location();
  final db = FirebaseDatabase.instance.ref();

  LatLng? myPos;
  LatLng? otherPos;
  late String myKey;

  @override
  void initState() {
    super.initState();
    myKey = DateTime.now().millisecondsSinceEpoch % 2 == 0
        ? "user1"
        : "user2";
    initLocation();
    listenOther();
  }

  void initLocation() async {
    await location.requestPermission();
    await location.enableBackgroundMode(enable: true);

    location.onLocationChanged.listen((loc) {
      if (loc.latitude != null && loc.longitude != null) {
        myPos = LatLng(loc.latitude!, loc.longitude!);
        db.child("sessions/${widget.sessionId}/$myKey").set({
          "lat": loc.latitude,
          "lng": loc.longitude,
        });
        setState(() {});
      }
    });
  }

  void listenOther() {
    String otherKey = myKey == "user1" ? "user2" : "user1";

    db.child("sessions/${widget.sessionId}/$otherKey")
        .onValue
        .listen((event) {
      if (event.snapshot.value != null) {
        final data = Map<String, dynamic>.from(
            event.snapshot.value as Map);
        otherPos = LatLng(data["lat"], data["lng"]);
        setState(() {});
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: myPos == null
          ? const Center(child: CircularProgressIndicator())
          : GoogleMap(
              initialCameraPosition:
                  CameraPosition(target: myPos!, zoom: 15),
              markers: {
                Marker(
                  markerId: const MarkerId("me"),
                  position: myPos!,
                ),
                if (otherPos != null)
                  Marker(
                    markerId: const MarkerId("other"),
                    position: otherPos!,
                  ),
              },
            ),
    );
  }
}
